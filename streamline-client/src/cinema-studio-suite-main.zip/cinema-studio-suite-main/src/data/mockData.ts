export const project = {
  name: "Midnight Run",
  scene: "Scene 03",
  shot: "Shot B",
  take: "Take 04",
  status: "Recording Ready" as const,
  resolution: "4K UHD",
  frameRate: "23.976 fps",
  codec: "ProRes 422 HQ",
  cameras: ["Camera A", "Camera B", "BTS Cam"],
  audioInputs: ["Boom Mic", "Lav 1", "Lav 2"],
};

export interface Clip {
  id: string;
  name: string;
  duration: string;
  durationSeconds: number;
  camera: string;
  scene: string;
  shot: string;
  take: string;
  date: string;
  tags: string[];
  status: "synced" | "pending" | "proxy" | "raw";
  favorite: boolean;
  resolution: string;
  fps: string;
}

export const clips: Clip[] = [
  { id: "1", name: "MR_S03_SB_T01_CamA", duration: "00:02:34", durationSeconds: 154, camera: "Camera A", scene: "Scene 03", shot: "Shot B", take: "Take 01", date: "2026-03-06 14:23", tags: ["dialogue", "wide"], status: "synced", favorite: true, resolution: "3840x2160", fps: "23.976" },
  { id: "2", name: "MR_S03_SB_T01_CamB", duration: "00:02:34", durationSeconds: 154, camera: "Camera B", scene: "Scene 03", shot: "Shot B", take: "Take 01", date: "2026-03-06 14:23", tags: ["close-up"], status: "synced", favorite: false, resolution: "3840x2160", fps: "23.976" },
  { id: "3", name: "MR_S03_SB_T02_CamA", duration: "00:01:48", durationSeconds: 108, camera: "Camera A", scene: "Scene 03", shot: "Shot B", take: "Take 02", date: "2026-03-06 14:31", tags: ["dialogue", "wide"], status: "synced", favorite: true, resolution: "3840x2160", fps: "23.976" },
  { id: "4", name: "MR_S03_SB_T03_CamA", duration: "00:03:12", durationSeconds: 192, camera: "Camera A", scene: "Scene 03", shot: "Shot B", take: "Take 03", date: "2026-03-06 14:40", tags: ["action"], status: "proxy", favorite: false, resolution: "3840x2160", fps: "23.976" },
  { id: "5", name: "MR_S03_SA_T01_CamA", duration: "00:01:15", durationSeconds: 75, camera: "Camera A", scene: "Scene 03", shot: "Shot A", take: "Take 01", date: "2026-03-06 13:55", tags: ["establishing"], status: "raw", favorite: false, resolution: "3840x2160", fps: "23.976" },
  { id: "6", name: "MR_S03_SC_T01_BTS", duration: "00:05:44", durationSeconds: 344, camera: "BTS Cam", scene: "Scene 03", shot: "Shot C", take: "Take 01", date: "2026-03-06 15:02", tags: ["bts", "handheld"], status: "pending", favorite: false, resolution: "1920x1080", fps: "29.97" },
  { id: "7", name: "MR_S02_SA_T02_CamA", duration: "00:02:01", durationSeconds: 121, camera: "Camera A", scene: "Scene 02", shot: "Shot A", take: "Take 02", date: "2026-03-05 10:15", tags: ["dialogue"], status: "synced", favorite: true, resolution: "3840x2160", fps: "23.976" },
  { id: "8", name: "MR_S01_SA_T01_CamA", duration: "00:04:22", durationSeconds: 262, camera: "Camera A", scene: "Scene 01", shot: "Shot A", take: "Take 01", date: "2026-03-04 09:30", tags: ["opening", "wide"], status: "synced", favorite: true, resolution: "3840x2160", fps: "23.976" },
];

export interface TimelineTrack {
  id: string;
  label: string;
  type: "video" | "audio";
  clips: TimelineClip[];
  muted: boolean;
  solo: boolean;
  locked: boolean;
}

export interface TimelineClip {
  id: string;
  name: string;
  startFrame: number;
  endFrame: number;
  camera?: string;
  scene?: string;
  color: string;
}

export const timelineTracks: TimelineTrack[] = [
  {
    id: "v3", label: "V3", type: "video", muted: false, solo: false, locked: false,
    clips: [
      { id: "tc1", name: "Title Card", startFrame: 0, endFrame: 72, color: "hsl(270 60% 45%)", scene: "Titles" },
    ],
  },
  {
    id: "v2", label: "V2", type: "video", muted: false, solo: false, locked: false,
    clips: [
      { id: "tc2", name: "CamB Close-up", startFrame: 120, endFrame: 300, camera: "Camera B", scene: "S03", color: "hsl(200 70% 40%)" },
      { id: "tc3", name: "CamB React", startFrame: 380, endFrame: 500, camera: "Camera B", scene: "S03", color: "hsl(200 70% 40%)" },
    ],
  },
  {
    id: "v1", label: "V1", type: "video", muted: false, solo: false, locked: false,
    clips: [
      { id: "tc4", name: "CamA Wide Master", startFrame: 0, endFrame: 280, camera: "Camera A", scene: "S03", color: "hsl(190 80% 35%)" },
      { id: "tc5", name: "CamA Wide T02", startFrame: 290, endFrame: 520, camera: "Camera A", scene: "S03", color: "hsl(190 80% 35%)" },
      { id: "tc6", name: "CamA Action", startFrame: 530, endFrame: 720, camera: "Camera A", scene: "S03", color: "hsl(190 60% 30%)" },
    ],
  },
  {
    id: "a1", label: "A1", type: "audio", muted: false, solo: false, locked: false,
    clips: [
      { id: "tc7", name: "Boom Dialogue", startFrame: 0, endFrame: 520, color: "hsl(142 50% 30%)" },
      { id: "tc8", name: "Boom Action", startFrame: 530, endFrame: 720, color: "hsl(142 50% 30%)" },
    ],
  },
  {
    id: "a2", label: "A2", type: "audio", muted: false, solo: false, locked: false,
    clips: [
      { id: "tc9", name: "Lav 1 Dialogue", startFrame: 0, endFrame: 520, color: "hsl(100 40% 28%)" },
    ],
  },
];

export const mediaTree = [
  {
    name: "Midnight Run",
    children: [
      {
        name: "Scenes",
        children: [
          { name: "Scene 01", children: [{ name: "Shot A" }, { name: "Shot B" }] },
          { name: "Scene 02", children: [{ name: "Shot A" }] },
          {
            name: "Scene 03",
            children: [{ name: "Shot A" }, { name: "Shot B" }, { name: "Shot C" }],
          },
        ],
      },
      {
        name: "Raw Footage",
        children: [{ name: "Camera A" }, { name: "Camera B" }, { name: "BTS" }],
      },
      {
        name: "Audio",
        children: [{ name: "Boom" }, { name: "Lavs" }],
      },
      { name: "Stills" },
      { name: "Exports" },
      { name: "Proxies" },
    ],
  },
];

export const recentProjects = [
  { name: "Midnight Run", scenes: 8, status: "Active Shoot", updated: "Today" },
  { name: "Echoes of Dawn", scenes: 12, status: "Post-Production", updated: "Yesterday" },
  { name: "The Last Signal", scenes: 5, status: "Pre-Production", updated: "Mar 3" },
];

export const exportQueue = [
  { name: "MR_S02_RoughCut_v3.mp4", progress: 78, format: "H.264", resolution: "4K" },
  { name: "MR_S01_Final.mov", progress: 100, format: "ProRes", resolution: "4K" },
  { name: "MR_BTS_Reel.mp4", progress: 0, format: "H.264", resolution: "1080p" },
];
