import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import { TimelineEditor } from "@/components/editing/TimelineEditor";
import { InspectorPanel } from "@/components/shared/InspectorPanel";
import { Camera, Film, Monitor } from "lucide-react";

export default function Editing() {
  const [selectedClipId, setSelectedClipId] = useState("1");

  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex flex-1 min-h-0">
        {/* Main editing area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Monitors */}
          <div className="flex gap-2 p-2 flex-1 min-h-0">
            {/* Source monitor */}
            <div className="flex-1 panel flex flex-col">
              <div className="px-2 py-1 border-b border-border flex items-center gap-1.5">
                <Film className="h-3 w-3 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Source</span>
                <span className="text-[10px] font-mono text-foreground ml-auto">MR_S03_SB_T01_CamA</span>
              </div>
              <div className="flex-1 bg-black rounded-b-lg flex items-center justify-center min-h-[150px]">
                <Camera className="h-12 w-12 text-muted-foreground/15" />
              </div>
            </div>

            {/* Program monitor */}
            <div className="flex-1 panel flex flex-col">
              <div className="px-2 py-1 border-b border-border flex items-center gap-1.5">
                <Monitor className="h-3 w-3 text-primary" />
                <span className="text-[10px] text-primary uppercase tracking-wider font-medium">Program</span>
                <span className="text-[10px] font-mono text-foreground ml-auto">01:23:45:12</span>
              </div>
              <div className="flex-1 bg-black rounded-b-lg flex items-center justify-center min-h-[150px] relative">
                <Camera className="h-12 w-12 text-muted-foreground/15" />
                {/* Safe area guides */}
                <div className="absolute inset-[10%] border border-muted-foreground/10 rounded" />
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="h-[280px] shrink-0">
            <TimelineEditor />
          </div>
        </div>

        {/* Inspector */}
        <InspectorPanel selectedClipId={selectedClipId} />
      </div>
    </AppShell>
  );
}
