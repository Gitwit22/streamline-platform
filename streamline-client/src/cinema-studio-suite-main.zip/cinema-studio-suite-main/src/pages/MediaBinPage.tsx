import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import { MediaTree } from "@/components/media/MediaTree";
import { MediaBin } from "@/components/media/MediaBin";
import { InspectorPanel } from "@/components/shared/InspectorPanel";

export default function MediaBinPage() {
  const [selectedClipId, setSelectedClipId] = useState("1");

  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex flex-1 min-h-0">
        {/* File tree */}
        <div className="w-56 border-r border-border overflow-y-auto bg-card shrink-0">
          <div className="px-3 py-2 border-b border-border">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
              Project Files
            </span>
          </div>
          <MediaTree />
        </div>

        {/* Media bin */}
        <div className="flex-1 overflow-y-auto bg-background">
          <div className="px-3 py-2 border-b border-border flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
              Media Bin — 8 clips
            </span>
            <div className="flex gap-1">
              {["All", "Synced", "Pending", "Favorites"].map((f) => (
                <button
                  key={f}
                  className="text-[10px] px-2 py-0.5 rounded bg-secondary text-muted-foreground hover:text-foreground"
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
          <MediaBin onClipSelect={setSelectedClipId} selectedId={selectedClipId} />
        </div>

        {/* Inspector */}
        <InspectorPanel selectedClipId={selectedClipId} />
      </div>
    </AppShell>
  );
}
