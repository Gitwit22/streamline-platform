import { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import { LiveCapturePanel } from "@/components/capture/LiveCapturePanel";
import { InspectorPanel } from "@/components/shared/InspectorPanel";

export default function Capture() {
  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex flex-1 min-h-0">
        <LiveCapturePanel />
        <InspectorPanel />
      </div>
    </AppShell>
  );
}
