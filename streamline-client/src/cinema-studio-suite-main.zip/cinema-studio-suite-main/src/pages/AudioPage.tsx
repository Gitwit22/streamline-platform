import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import { AudioMixerPanel } from "@/components/audio/AudioMixerPanel";

export default function AudioPage() {
  return (
    <AppShell>
      <ProjectHeader />
      <AudioMixerPanel />
    </AppShell>
  );
}
