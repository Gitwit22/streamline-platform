import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import {
  Film,
  Video,
  Calendar,
  HardDrive,
  Clock,
  Music,
  Download,
  Users,
  Sparkles,
  Play,
} from "lucide-react";
import { recentProjects, exportQueue, clips } from "@/data/mockData";

export default function Dashboard() {
  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-7xl mx-auto space-y-4">
          {/* Header */}
          <div>
            <h2 className="text-lg font-semibold text-foreground">Production Dashboard</h2>
            <p className="text-xs text-muted-foreground">Midnight Run — Day 3 of Production</p>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-4 gap-3">
            <StatCard icon={Film} label="Total Takes" value="47" />
            <StatCard icon={Clock} label="Footage" value="3h 24m" />
            <StatCard icon={HardDrive} label="Storage" value="412 GB" sub="1.2 TB free" />
            <StatCard icon={Music} label="Audio Sync" value="94%" color="text-ready" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            {/* Recent Projects */}
            <div className="panel p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
                Recent Projects
              </div>
              <div className="space-y-2">
                {recentProjects.map((p) => (
                  <div key={p.name} className="flex items-center justify-between py-1.5">
                    <div>
                      <div className="text-xs text-foreground font-medium">{p.name}</div>
                      <div className="text-[10px] text-muted-foreground">
                        {p.scenes} scenes • {p.status}
                      </div>
                    </div>
                    <span className="text-[10px] text-muted-foreground">{p.updated}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Today's Scenes */}
            <div className="panel p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
                <Calendar className="h-3 w-3 inline mr-1" />
                Today's Schedule
              </div>
              <div className="space-y-1.5">
                {[
                  { scene: "Scene 03 — Shot A", time: "09:00", status: "Complete", color: "text-ready" },
                  { scene: "Scene 03 — Shot B", time: "11:30", status: "In Progress", color: "text-primary" },
                  { scene: "Scene 03 — Shot C", time: "14:00", status: "Upcoming", color: "text-muted-foreground" },
                  { scene: "Scene 04 — Shot A", time: "16:00", status: "Upcoming", color: "text-muted-foreground" },
                ].map((s) => (
                  <div key={s.scene} className="flex items-center justify-between py-1">
                    <div className="text-xs text-foreground">{s.scene}</div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground font-mono">{s.time}</span>
                      <span className={`text-[10px] ${s.color}`}>{s.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Export Queue */}
            <div className="panel p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
                <Download className="h-3 w-3 inline mr-1" />
                Export Queue
              </div>
              <div className="space-y-2">
                {exportQueue.map((e) => (
                  <div key={e.name} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-foreground font-mono truncate mr-2">
                        {e.name}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {e.progress}%
                      </span>
                    </div>
                    <div className="h-1 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          e.progress === 100 ? "bg-ready" : "bg-primary"
                        }`}
                        style={{ width: `${e.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Takes */}
          <div className="panel p-3">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
              Recent Takes
            </div>
            <div className="grid grid-cols-4 gap-2">
              {clips.slice(0, 4).map((clip) => (
                <div key={clip.id} className="bg-secondary rounded-md p-2 space-y-1.5">
                  <div className="aspect-video bg-background rounded flex items-center justify-center">
                    <Play className="h-6 w-6 text-muted-foreground/30" />
                  </div>
                  <div className="text-[10px] font-mono text-foreground truncate">{clip.name}</div>
                  <div className="flex items-center gap-1.5 text-[9px] text-muted-foreground">
                    <span>{clip.duration}</span>
                    <span>•</span>
                    <span>{clip.camera}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Tools & Team */}
          <div className="grid grid-cols-2 gap-3">
            <div className="panel p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
                <Sparkles className="h-3 w-3 text-primary" /> AI Tools
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {["Auto Rough Cut", "Best Take Suggestion", "Auto Sync", "Dialogue Cleanup", "Smart Multicam", "Scene Detection"].map(
                  (tool) => (
                    <button
                      key={tool}
                      className="text-[10px] py-2 px-2 rounded bg-primary/5 text-primary/70 hover:bg-primary/10 hover:text-primary transition-colors text-left"
                    >
                      {tool}
                    </button>
                  )
                )}
              </div>
            </div>

            <div className="panel p-3">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
                <Users className="h-3 w-3" /> Team Activity
              </div>
              <div className="space-y-1.5">
                {[
                  { name: "Alex Chen", action: "Completed Scene 02 rough cut", time: "2m ago" },
                  { name: "Maria Santos", action: "Synced audio for Scene 03", time: "15m ago" },
                  { name: "James Wilson", action: "Exported BTS reel", time: "1h ago" },
                  { name: "Sarah Kim", action: "Added markers to Take 03", time: "2h ago" },
                ].map((a) => (
                  <div key={a.name} className="flex items-center justify-between py-1">
                    <div>
                      <span className="text-xs text-foreground">{a.name}</span>
                      <span className="text-[10px] text-muted-foreground ml-1.5">{a.action}</span>
                    </div>
                    <span className="text-[10px] text-muted-foreground">{a.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color = "text-foreground",
}: {
  icon: any;
  label: string;
  value: string;
  sub?: string;
  color?: string;
}) {
  return (
    <div className="panel p-3 flex items-center gap-3">
      <div className="h-9 w-9 rounded-md bg-secondary flex items-center justify-center">
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div>
        <div className={`text-lg font-semibold font-mono ${color}`}>{value}</div>
        <div className="text-[10px] text-muted-foreground">{label}</div>
        {sub && <div className="text-[9px] text-muted-foreground/60">{sub}</div>}
      </div>
    </div>
  );
}
