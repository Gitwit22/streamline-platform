import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";
import { exportQueue } from "@/data/mockData";
import { Download, Film, CheckCircle, Clock, Plus } from "lucide-react";
import { toast } from "sonner";

export default function Exports() {
  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-foreground">Export Queue</h2>
            <button
              className="flex items-center gap-1.5 text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-md hover:bg-primary/80"
              onClick={() => toast.success("Export queued")}
            >
              <Plus className="h-3 w-3" /> New Export
            </button>
          </div>

          <div className="space-y-2">
            {exportQueue.map((item) => (
              <div key={item.name} className="panel p-4 flex items-center gap-4">
                <div className="h-10 w-10 rounded-md bg-secondary flex items-center justify-center shrink-0">
                  {item.progress === 100 ? (
                    <CheckCircle className="h-5 w-5 text-ready" />
                  ) : item.progress > 0 ? (
                    <Download className="h-5 w-5 text-primary" />
                  ) : (
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-mono text-foreground">{item.name}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {item.format} • {item.resolution}
                  </div>
                  <div className="h-1.5 bg-secondary rounded-full mt-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        item.progress === 100 ? "bg-ready" : "bg-primary"
                      }`}
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                </div>
                <span className="text-sm font-mono text-muted-foreground">{item.progress}%</span>
              </div>
            ))}
          </div>

          {/* Export presets */}
          <div className="panel p-3">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
              Export Presets
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { name: "ProRes Master", desc: "ProRes 422 HQ • 4K • Full Quality" },
                { name: "H.264 Review", desc: "H.264 • 1080p • Fast Encode" },
                { name: "Web Preview", desc: "H.264 • 720p • Low Bitrate" },
                { name: "DCP Package", desc: "JPEG2000 • 4K • Cinema" },
                { name: "Audio Only", desc: "WAV 48kHz • 24bit • Stems" },
                { name: "Proxy Files", desc: "ProRes Proxy • 1080p" },
              ].map((preset) => (
                <button
                  key={preset.name}
                  className="text-left p-2.5 rounded-md bg-secondary hover:bg-secondary/80 transition-colors"
                  onClick={() => toast.success(`${preset.name} export queued`)}
                >
                  <div className="text-xs text-foreground font-medium">{preset.name}</div>
                  <div className="text-[10px] text-muted-foreground">{preset.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
