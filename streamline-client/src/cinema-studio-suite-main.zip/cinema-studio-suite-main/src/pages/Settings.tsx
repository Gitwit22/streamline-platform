import { AppShell } from "@/components/layout/AppShell";
import { ProjectHeader } from "@/components/layout/ProjectHeader";

export default function Settings() {
  return (
    <AppShell>
      <ProjectHeader />
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          <h2 className="text-lg font-semibold text-foreground">Settings</h2>

          {[
            {
              title: "Project Settings",
              items: [
                { label: "Project Name", value: "Midnight Run" },
                { label: "Frame Rate", value: "23.976 fps" },
                { label: "Resolution", value: "3840 x 2160" },
                { label: "Codec", value: "ProRes 422 HQ" },
                { label: "Color Space", value: "Rec. 709" },
              ],
            },
            {
              title: "Storage",
              items: [
                { label: "Project Location", value: "/Volumes/Production/MidnightRun" },
                { label: "Proxy Location", value: "/Volumes/Production/MidnightRun/Proxies" },
                { label: "Auto-backup", value: "Enabled — Every 5 min" },
              ],
            },
            {
              title: "Capture",
              items: [
                { label: "Default Camera", value: "Camera A" },
                { label: "Audio Sample Rate", value: "48 kHz" },
                { label: "Auto-increment Takes", value: "Enabled" },
                { label: "Auto-save Takes", value: "Enabled" },
              ],
            },
          ].map((section) => (
            <div key={section.title} className="panel p-4 space-y-3">
              <h3 className="text-sm font-medium text-foreground">{section.title}</h3>
              <div className="space-y-2">
                {section.items.map((item) => (
                  <div key={item.label} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <span className="text-xs text-muted-foreground">{item.label}</span>
                    <span className="text-xs text-foreground font-mono">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
