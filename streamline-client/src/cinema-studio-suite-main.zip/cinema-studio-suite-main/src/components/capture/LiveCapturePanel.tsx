import { useState } from "react";
import {
  Circle,
  Square,
  Pause,
  RotateCcw,
  Bookmark,
  Camera,
  Volume2,
  Plus,
  Save,
  Eye,
} from "lucide-react";
import { project } from "@/data/mockData";
import { toast } from "sonner";

export function LiveCapturePanel() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState("Camera A");
  const [timer, setTimer] = useState("00:00:00:00");

  const handleRecord = () => {
    setIsRecording(true);
    setIsPaused(false);
    toast.success("Recording started");
  };

  const handleStop = () => {
    setIsRecording(false);
    setIsPaused(false);
    toast.success("Take saved");
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  return (
    <div className="flex-1 flex flex-col gap-3 p-3 min-h-0">
      {/* Scene / Shot / Take bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {["Scene 03", "Shot B", "Take 04"].map((item) => (
            <span key={item} className="bg-secondary text-foreground text-xs font-mono px-2.5 py-1 rounded-md">
              {item}
            </span>
          ))}
          <button
            className="flex items-center gap-1 text-xs text-primary hover:text-primary/80 ml-2"
            onClick={() => toast("New take started", { description: "Take 05 ready" })}
          >
            <Plus className="h-3 w-3" /> New Take
          </button>
        </div>
        <button
          className="flex items-center gap-1 text-xs bg-primary/10 text-primary hover:bg-primary/20 px-3 py-1.5 rounded-md transition-colors"
          onClick={() => toast.success("Saved to Scene 03")}
        >
          <Save className="h-3 w-3" /> Save to Scene
        </button>
      </div>

      {/* Camera selector */}
      <div className="flex items-center gap-1">
        {project.cameras.map((cam) => (
          <button
            key={cam}
            onClick={() => setSelectedCamera(cam)}
            className={`text-xs px-3 py-1.5 rounded-md transition-colors ${
              selectedCamera === cam
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            {cam}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
          {project.cameras.map((cam) => (
            <span key={cam} className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-ready" />
              {cam.replace("Camera ", "Cam ")}
            </span>
          ))}
        </div>
      </div>

      {/* Preview area */}
      <div className="flex-1 relative bg-black rounded-lg overflow-hidden border border-border min-h-[300px] flex items-center justify-center">
        {/* Cinematic bars */}
        <div className="absolute inset-x-0 top-0 h-[8%] bg-black z-10" />
        <div className="absolute inset-x-0 bottom-0 h-[8%] bg-black z-10" />

        {/* Preview content */}
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Camera className="h-16 w-16 text-muted-foreground/20" />
          <span className="text-sm">{selectedCamera} — Live Feed</span>
          <span className="text-xs text-muted-foreground/60">
            {project.resolution} • {project.frameRate}
          </span>
        </div>

        {/* Recording indicator */}
        {isRecording && (
          <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-recording animate-recording-pulse" />
            <span className="text-xs font-mono text-recording font-semibold">
              {isPaused ? "PAUSED" : "REC"}
            </span>
          </div>
        )}

        {/* Timer */}
        <div className="absolute top-4 right-4 z-20 bg-black/70 px-3 py-1 rounded">
          <span className="text-sm font-mono text-foreground">
            {isRecording ? "00:01:23:15" : timer}
          </span>
        </div>

        {/* Resolution badge */}
        <div className="absolute bottom-[10%] left-4 z-20 flex gap-1.5">
          <span className="bg-black/70 px-2 py-0.5 rounded text-[10px] font-mono text-foreground">
            4K
          </span>
          <span className="bg-black/70 px-2 py-0.5 rounded text-[10px] font-mono text-foreground">
            23.976
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-2">
        <button
          onClick={handleRecord}
          disabled={isRecording}
          className={`h-10 w-10 rounded-full flex items-center justify-center transition-colors ${
            isRecording
              ? "bg-recording/20 text-recording"
              : "bg-recording text-destructive-foreground hover:bg-recording/80"
          }`}
        >
          <Circle className="h-5 w-5 fill-current" />
        </button>
        <button
          onClick={handleStop}
          disabled={!isRecording}
          className="h-10 w-10 rounded-full bg-secondary text-foreground flex items-center justify-center hover:bg-secondary/80 disabled:opacity-30"
        >
          <Square className="h-4 w-4 fill-current" />
        </button>
        <button
          onClick={handlePause}
          disabled={!isRecording}
          className="h-10 w-10 rounded-full bg-secondary text-foreground flex items-center justify-center hover:bg-secondary/80 disabled:opacity-30"
        >
          <Pause className="h-4 w-4" />
        </button>

        <div className="w-px h-6 bg-border mx-2" />

        <button
          className="h-9 px-3 rounded-md bg-secondary text-xs text-foreground flex items-center gap-1.5 hover:bg-secondary/80"
          onClick={() => toast("Marker added at 00:01:23:15")}
        >
          <Bookmark className="h-3.5 w-3.5" /> Marker
        </button>
        <button
          className="h-9 px-3 rounded-md bg-secondary text-xs text-foreground flex items-center gap-1.5 hover:bg-secondary/80"
          onClick={() => toast.success("Snapshot captured")}
        >
          <Camera className="h-3.5 w-3.5" /> Snapshot
        </button>
        <button
          className="h-9 px-3 rounded-md bg-secondary text-xs text-foreground flex items-center gap-1.5 hover:bg-secondary/80"
          onClick={() => toast("Replaying last take...")}
        >
          <RotateCcw className="h-3.5 w-3.5" /> Replay Last
        </button>
      </div>

      {/* Audio meters + Script notes */}
      <div className="flex gap-3">
        {/* Audio meters */}
        <div className="flex gap-3 panel p-2.5">
          {project.audioInputs.map((input) => (
            <div key={input} className="flex flex-col items-center gap-1">
              <div className="flex gap-0.5 items-end h-12">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-1 rounded-full ${
                      i < 5 ? "bg-ready" : i < 7 ? "bg-warning" : "bg-recording"
                    }`}
                    style={{ height: `${Math.random() * 60 + 20}%` }}
                  />
                ))}
              </div>
              <span className="text-[9px] text-muted-foreground whitespace-nowrap">{input}</span>
              <Volume2 className="h-3 w-3 text-muted-foreground" />
            </div>
          ))}
        </div>

        {/* Script notes */}
        <div className="flex-1 panel p-2.5">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">
            Script Supervisor Notes
          </div>
          <textarea
            className="w-full bg-transparent text-xs text-foreground resize-none h-12 outline-none placeholder:text-muted-foreground/50"
            placeholder="Add notes for this take..."
            defaultValue="Good continuity. Actor entered from camera right. Watch coffee cup placement."
          />
        </div>
      </div>
    </div>
  );
}
