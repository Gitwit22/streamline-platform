import { useState } from "react";
import { Volume2, VolumeX, Headphones, Sparkles } from "lucide-react";
import { project } from "@/data/mockData";
import { toast } from "sonner";

const audioTracks = [
  { id: "boom", label: "Boom Mic", level: 72, pan: 0 },
  { id: "lav1", label: "Lav 1", level: 65, pan: -15 },
  { id: "lav2", label: "Lav 2", level: 58, pan: 20 },
  { id: "ambient", label: "Ambient", level: 30, pan: 0 },
  { id: "sfx", label: "SFX", level: 45, pan: 0 },
];

const effects = [
  "Noise Reduction",
  "EQ (Parametric)",
  "Compressor",
  "Voice Enhance",
  "De-Esser",
  "Limiter",
];

export function AudioMixerPanel() {
  const [tracks, setTracks] = useState(audioTracks);
  const [muted, setMuted] = useState<Set<string>>(new Set());
  const [soloed, setSoloed] = useState<Set<string>>(new Set());

  const toggleMute = (id: string) => {
    setMuted((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSolo = (id: string) => {
    setSoloed((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <div className="flex-1 flex gap-3 p-3 min-h-0 overflow-auto">
      {/* Waveform area */}
      <div className="flex-1 flex flex-col gap-3">
        <div className="panel p-3 flex-1 min-h-[200px]">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
            Waveform Display
          </div>
          <div className="flex-1 h-40 bg-secondary/50 rounded-md flex items-center justify-center relative overflow-hidden">
            {/* Fake waveform */}
            <div className="absolute inset-0 flex items-center px-2">
              <div className="flex items-center gap-px w-full h-full">
                {Array.from({ length: 200 }).map((_, i) => {
                  const h = Math.sin(i * 0.15) * 30 + Math.random() * 20 + 10;
                  return (
                    <div
                      key={i}
                      className="flex-1 bg-ready/40 rounded-sm"
                      style={{ height: `${h}%`, minWidth: 1 }}
                    />
                  );
                })}
              </div>
            </div>
            {/* Playhead */}
            <div className="absolute left-[35%] top-0 bottom-0 w-px bg-recording z-10" />
          </div>
        </div>

        {/* Effects */}
        <div className="panel p-3">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">
            Audio Effects Chain
          </div>
          <div className="flex flex-wrap gap-1.5">
            {effects.map((fx) => (
              <button
                key={fx}
                className="text-[10px] px-2.5 py-1.5 rounded bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors"
              >
                {fx}
              </button>
            ))}
          </div>
        </div>

        {/* AI tools */}
        <div className="panel p-3">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-primary" /> AI Audio Tools
          </div>
          <div className="flex gap-2">
            <button
              className="flex-1 text-xs py-2 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
              onClick={() => toast.success("Audio synced automatically")}
            >
              Auto Sync Audio
            </button>
            <button
              className="flex-1 text-xs py-2 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
              onClick={() => toast.success("Dialogue cleaned up")}
            >
              Clean Dialogue
            </button>
          </div>
        </div>
      </div>

      {/* Mixer */}
      <div className="w-72 panel p-3 flex flex-col">
        <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3">
          Mixer
        </div>
        <div className="flex gap-2 flex-1">
          {tracks.map((track) => (
            <div key={track.id} className="flex flex-col items-center gap-2 flex-1">
              {/* Meter */}
              <div className="w-3 flex-1 min-h-[120px] bg-secondary rounded-full relative overflow-hidden">
                <div
                  className="absolute bottom-0 inset-x-0 rounded-full transition-all"
                  style={{
                    height: `${muted.has(track.id) ? 0 : track.level}%`,
                    background: track.level > 85 ? "hsl(var(--recording))" : track.level > 70 ? "hsl(var(--warning))" : "hsl(var(--ready))",
                  }}
                />
              </div>

              {/* Level */}
              <span className="text-[9px] font-mono text-muted-foreground">
                {muted.has(track.id) ? "-∞" : `-${100 - track.level}`}
              </span>

              {/* Mute/Solo */}
              <div className="flex gap-0.5">
                <button
                  onClick={() => toggleMute(track.id)}
                  className={`h-5 w-5 rounded text-[8px] flex items-center justify-center ${
                    muted.has(track.id) ? "bg-recording/20 text-recording" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  M
                </button>
                <button
                  onClick={() => toggleSolo(track.id)}
                  className={`h-5 w-5 rounded text-[8px] flex items-center justify-center ${
                    soloed.has(track.id) ? "bg-warning/20 text-warning" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  S
                </button>
              </div>

              {/* Label */}
              <span className="text-[8px] text-muted-foreground text-center leading-tight">
                {track.label}
              </span>
            </div>
          ))}

          {/* Master */}
          <div className="flex flex-col items-center gap-2 flex-1 border-l border-border pl-2">
            <div className="w-3 flex-1 min-h-[120px] bg-secondary rounded-full relative overflow-hidden">
              <div
                className="absolute bottom-0 inset-x-0 bg-primary rounded-full"
                style={{ height: "68%" }}
              />
            </div>
            <span className="text-[9px] font-mono text-primary">-6</span>
            <Headphones className="h-3.5 w-3.5 text-primary" />
            <span className="text-[8px] text-primary font-medium">Master</span>
          </div>
        </div>
      </div>
    </div>
  );
}
