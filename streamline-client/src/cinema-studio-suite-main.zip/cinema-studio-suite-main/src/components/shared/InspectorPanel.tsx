import { clips } from "@/data/mockData";
import { Star, Tag, Camera, Clock, Film, Info } from "lucide-react";

interface InspectorPanelProps {
  selectedClipId?: string;
}

export function InspectorPanel({ selectedClipId }: InspectorPanelProps) {
  const clip = clips.find((c) => c.id === (selectedClipId || "1"));

  if (!clip) return null;

  return (
    <aside className="w-64 h-full bg-card border-l border-border flex flex-col shrink-0 overflow-y-auto">
      <div className="px-3 py-2.5 border-b border-border">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Inspector
        </h3>
      </div>

      {/* Preview thumbnail */}
      <div className="mx-3 mt-3 aspect-video bg-secondary rounded-md flex items-center justify-center">
        <Film className="h-8 w-8 text-muted-foreground/40" />
      </div>

      <div className="p-3 space-y-4 text-xs">
        {/* Clip name */}
        <div>
          <div className="text-muted-foreground mb-1">Clip Name</div>
          <div className="text-foreground font-mono text-[11px]">{clip.name}</div>
        </div>

        {/* Metadata grid */}
        <div className="grid grid-cols-2 gap-2">
          <MetaItem icon={Camera} label="Camera" value={clip.camera} />
          <MetaItem icon={Clock} label="Duration" value={clip.duration} />
          <MetaItem icon={Info} label="Resolution" value={clip.resolution} />
          <MetaItem icon={Info} label="Frame Rate" value={clip.fps} />
        </div>

        {/* Scene info */}
        <div className="space-y-1.5">
          <div className="text-muted-foreground">Scene / Shot / Take</div>
          <div className="flex gap-1.5">
            <span className="bg-secondary px-1.5 py-0.5 rounded text-foreground font-mono">
              {clip.scene}
            </span>
            <span className="bg-secondary px-1.5 py-0.5 rounded text-foreground font-mono">
              {clip.shot}
            </span>
            <span className="bg-secondary px-1.5 py-0.5 rounded text-foreground font-mono">
              {clip.take}
            </span>
          </div>
        </div>

        {/* Status */}
        <div>
          <div className="text-muted-foreground mb-1">Status</div>
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wide ${
              clip.status === "synced"
                ? "bg-ready/15 text-ready"
                : clip.status === "proxy"
                ? "bg-primary/15 text-primary"
                : clip.status === "pending"
                ? "bg-warning/15 text-warning"
                : "bg-secondary text-muted-foreground"
            }`}
          >
            {clip.status}
          </span>
        </div>

        {/* Tags */}
        <div>
          <div className="text-muted-foreground mb-1.5 flex items-center gap-1">
            <Tag className="h-3 w-3" /> Tags
          </div>
          <div className="flex flex-wrap gap-1">
            {clip.tags.map((tag) => (
              <span
                key={tag}
                className="bg-secondary px-1.5 py-0.5 rounded text-muted-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Favorite */}
        <div className="flex items-center gap-2">
          <Star
            className={`h-3.5 w-3.5 ${
              clip.favorite ? "fill-warning text-warning" : "text-muted-foreground"
            }`}
          />
          <span className="text-muted-foreground">
            {clip.favorite ? "Favorited" : "Not Favorited"}
          </span>
        </div>

        {/* Audio link */}
        <div className="space-y-1.5 pt-2 border-t border-border">
          <div className="text-muted-foreground">Audio Linked</div>
          <span className="text-ready">● Synced</span>
        </div>

        {/* Proxy */}
        <div>
          <div className="text-muted-foreground">Proxy Status</div>
          <span className={clip.status === "proxy" ? "text-primary" : "text-ready"}>
            {clip.status === "proxy" ? "● Proxy Available" : "● Original"}
          </span>
        </div>

        {/* Notes */}
        <div className="pt-2 border-t border-border">
          <div className="text-muted-foreground mb-1">Notes</div>
          <textarea
            className="w-full bg-secondary rounded-md p-2 text-xs text-foreground resize-none h-16 border-none outline-none focus:ring-1 focus:ring-primary"
            placeholder="Add notes..."
            defaultValue="Good energy. Watch for mic shadow at 1:23."
          />
        </div>

        {/* Color label */}
        <div>
          <div className="text-muted-foreground mb-1.5">Color Label</div>
          <div className="flex gap-1.5">
            {["hsl(0 72% 51%)", "hsl(38 92% 50%)", "hsl(142 71% 45%)", "hsl(190 100% 42%)", "hsl(270 60% 50%)"].map(
              (color, i) => (
                <button
                  key={i}
                  className={`h-4 w-4 rounded-full border-2 ${
                    i === 2 ? "border-foreground" : "border-transparent"
                  }`}
                  style={{ backgroundColor: color }}
                />
              )
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}

function MetaItem({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div>
      <div className="text-muted-foreground flex items-center gap-1 mb-0.5">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <div className="text-foreground font-mono text-[11px]">{value}</div>
    </div>
  );
}
