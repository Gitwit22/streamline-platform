import { clips, type Clip } from "@/data/mockData";
import { Star, Camera, Clock, Tag } from "lucide-react";

export function MediaBin({
  onClipSelect,
  selectedId,
}: {
  onClipSelect?: (id: string) => void;
  selectedId?: string;
}) {
  return (
    <div className="grid grid-cols-1 gap-1.5 p-2">
      {clips.map((clip) => (
        <button
          key={clip.id}
          onClick={() => onClipSelect?.(clip.id)}
          className={`flex items-center gap-3 p-2 rounded-md text-left transition-colors ${
            selectedId === clip.id
              ? "bg-primary/10 ring-1 ring-primary"
              : "hover:bg-secondary"
          }`}
        >
          {/* Thumbnail */}
          <div className="h-10 w-16 bg-secondary rounded flex items-center justify-center shrink-0">
            <Camera className="h-4 w-4 text-muted-foreground/40" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="text-xs font-mono text-foreground truncate">{clip.name}</div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                <Clock className="h-2.5 w-2.5" /> {clip.duration}
              </span>
              <span className="text-[10px] text-muted-foreground">{clip.camera}</span>
              <span
                className={`text-[9px] px-1 py-px rounded ${
                  clip.status === "synced"
                    ? "bg-ready/15 text-ready"
                    : clip.status === "proxy"
                    ? "bg-primary/15 text-primary"
                    : clip.status === "pending"
                    ? "bg-warning/15 text-warning"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {clip.status}
              </span>
            </div>
          </div>

          {/* Favorite */}
          <Star
            className={`h-3.5 w-3.5 shrink-0 ${
              clip.favorite ? "fill-warning text-warning" : "text-muted-foreground/30"
            }`}
          />
        </button>
      ))}
    </div>
  );
}
