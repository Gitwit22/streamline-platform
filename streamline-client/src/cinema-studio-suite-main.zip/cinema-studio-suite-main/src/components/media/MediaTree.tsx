import { useState } from "react";
import { ChevronRight, ChevronDown, Folder, FolderOpen, Film } from "lucide-react";
import { mediaTree } from "@/data/mockData";

interface TreeNode {
  name: string;
  children?: TreeNode[];
}

export function MediaTree({ onSelect }: { onSelect?: (name: string) => void }) {
  return (
    <div className="p-2 space-y-0.5">
      {mediaTree.map((node) => (
        <TreeItem key={node.name} node={node} depth={0} onSelect={onSelect} />
      ))}
    </div>
  );
}

function TreeItem({
  node,
  depth,
  onSelect,
}: {
  node: TreeNode;
  depth: number;
  onSelect?: (name: string) => void;
}) {
  const [open, setOpen] = useState(depth < 2);
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div>
      <button
        onClick={() => {
          if (hasChildren) setOpen(!open);
          onSelect?.(node.name);
        }}
        className="w-full flex items-center gap-1.5 px-1.5 py-1 rounded text-xs hover:bg-secondary/80 transition-colors group"
        style={{ paddingLeft: `${depth * 12 + 6}px` }}
      >
        {hasChildren ? (
          open ? (
            <ChevronDown className="h-3 w-3 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />
          )
        ) : (
          <span className="w-3 shrink-0" />
        )}
        {hasChildren ? (
          open ? (
            <FolderOpen className="h-3.5 w-3.5 text-warning shrink-0" />
          ) : (
            <Folder className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
          )
        ) : (
          <Film className="h-3.5 w-3.5 text-muted-foreground/60 shrink-0" />
        )}
        <span className="text-foreground/80 truncate">{node.name}</span>
      </button>
      {open && hasChildren && (
        <div>
          {node.children!.map((child) => (
            <TreeItem key={child.name} node={child} depth={depth + 1} onSelect={onSelect} />
          ))}
        </div>
      )}
    </div>
  );
}
