import { project } from "@/data/mockData";
import { Circle, Clock } from "lucide-react";

export function ProjectHeader() {
  return (
    <header className="h-12 flex items-center justify-between px-4 bg-card border-b border-border shrink-0">
      <div className="flex items-center gap-4">
        <h1 className="text-sm font-semibold text-foreground">{project.name}</h1>
        <span className="text-xs text-muted-foreground font-mono">
          {project.scene} / {project.shot} / {project.take}
        </span>
      </div>

      <div className="flex items-center gap-3">
        <span className="flex items-center gap-1.5 text-xs">
          <Circle className="h-2 w-2 fill-ready text-ready" />
          <span className="text-ready font-medium">{project.status}</span>
        </span>
        <span className="text-xs text-muted-foreground font-mono bg-secondary px-2 py-0.5 rounded">
          {project.resolution}
        </span>
        <span className="text-xs text-muted-foreground font-mono bg-secondary px-2 py-0.5 rounded">
          {project.frameRate}
        </span>
        <span className="text-xs text-muted-foreground font-mono bg-secondary px-2 py-0.5 rounded">
          {project.codec}
        </span>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span className="font-mono">01:23:45:12</span>
        </div>
      </div>
    </header>
  );
}
