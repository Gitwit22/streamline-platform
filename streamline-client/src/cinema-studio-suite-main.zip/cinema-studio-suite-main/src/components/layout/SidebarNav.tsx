import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  FolderOpen,
  Video,
  Film,
  Scissors,
  Music,
  Download,
  Settings,
  Clapperboard,
} from "lucide-react";

const navItems = [
  { label: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { label: "Projects", icon: FolderOpen, path: "/projects" },
  { label: "Live Capture", icon: Video, path: "/capture" },
  { label: "Media Bin", icon: Film, path: "/media" },
  { label: "Editing", icon: Scissors, path: "/editing" },
  { label: "Audio", icon: Music, path: "/audio" },
  { label: "Exports", icon: Download, path: "/exports" },
  { label: "Settings", icon: Settings, path: "/settings" },
];

export function SidebarNav() {
  const location = useLocation();

  return (
    <aside className="w-16 lg:w-52 h-screen flex flex-col bg-sidebar border-r border-sidebar-border shrink-0">
      {/* Logo */}
      <div className="h-14 flex items-center gap-2 px-3 border-b border-sidebar-border">
        <Clapperboard className="h-6 w-6 text-primary shrink-0" />
        <span className="hidden lg:block text-sm font-semibold text-foreground tracking-tight">
          StreamLine
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const active = location.pathname === item.path || 
            (item.path === "/dashboard" && location.pathname === "/");
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 lg:px-4 py-2.5 mx-1.5 rounded-md text-sm transition-colors ${
                active
                  ? "bg-sidebar-accent text-primary font-medium"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <item.icon className="h-4.5 w-4.5 shrink-0" />
              <span className="hidden lg:block truncate">{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-sidebar-border">
        <div className="hidden lg:flex items-center gap-2 px-1">
          <div className="h-2 w-2 rounded-full bg-ready" />
          <span className="text-xs text-muted-foreground">System Online</span>
        </div>
      </div>
    </aside>
  );
}
