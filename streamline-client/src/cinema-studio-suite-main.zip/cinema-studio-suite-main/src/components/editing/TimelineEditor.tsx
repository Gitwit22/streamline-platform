import { useState } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Scissors,
  Trash2,
  Copy,
  Magnet,
  ZoomIn,
  ZoomOut,
  Lock,
  Volume2,
  VolumeX,
  Eye,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { timelineTracks, type TimelineTrack, type TimelineClip } from "@/data/mockData";
import { toast } from "sonner";

const TOTAL_FRAMES = 800;
const PIXELS_PER_FRAME = 1.8;

export function TimelineEditor() {
  const [playheadFrame, setPlayheadFrame] = useState(180);
  const [zoom, setZoom] = useState(1);
  const [selectedClipId, setSelectedClipId] = useState<string | null>("tc4");
  const [isPlaying, setIsPlaying] = useState(false);
  const [tracks, setTracks] = useState(timelineTracks);
  const [snapping, setSnapping] = useState(true);

  const totalWidth = TOTAL_FRAMES * PIXELS_PER_FRAME * zoom;

  const framesToTimecode = (frames: number) => {
    const totalSeconds = frames / 24;
    const m = Math.floor(totalSeconds / 60);
    const s = Math.floor(totalSeconds % 60);
    const f = frames % 24;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`;
  };

  const toggleTrackProp = (trackId: string, prop: "muted" | "solo" | "locked") => {
    setTracks((prev) =>
      prev.map((t) => (t.id === trackId ? { ...t, [prop]: !t[prop] } : t))
    );
  };

  return (
    <div className="flex flex-col bg-card border-t border-border">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-border bg-panel">
        {/* Transport */}
        <div className="flex items-center gap-1">
          <ToolBtn icon={SkipBack} tooltip="Step Back" onClick={() => setPlayheadFrame(Math.max(0, playheadFrame - 24))} />
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="h-7 w-7 rounded flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/80"
          >
            {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          </button>
          <ToolBtn icon={SkipForward} tooltip="Step Forward" onClick={() => setPlayheadFrame(Math.min(TOTAL_FRAMES, playheadFrame + 24))} />
          <ToolBtn icon={Repeat} tooltip="Loop" />

          <div className="w-px h-5 bg-border mx-1.5" />

          {/* Timecode */}
          <span className="text-[11px] font-mono text-foreground bg-secondary px-2 py-0.5 rounded">
            {framesToTimecode(playheadFrame)}
          </span>
        </div>

        {/* Edit tools */}
        <div className="flex items-center gap-0.5">
          <ToolBtn icon={Scissors} tooltip="Split" onClick={() => toast("Split at playhead")} />
          <ToolBtn icon={ChevronLeft} tooltip="Trim Left" onClick={() => toast("Trim left")} />
          <ToolBtn icon={ChevronRight} tooltip="Trim Right" onClick={() => toast("Trim right")} />
          <ToolBtn icon={Trash2} tooltip="Ripple Delete" onClick={() => toast("Ripple deleted")} />
          <ToolBtn icon={Copy} tooltip="Duplicate" onClick={() => toast("Clip duplicated")} />
          <ToolBtn
            icon={Magnet}
            tooltip="Snap"
            active={snapping}
            onClick={() => setSnapping(!snapping)}
          />
        </div>

        {/* Zoom */}
        <div className="flex items-center gap-1.5">
          <ToolBtn icon={ZoomOut} tooltip="Zoom Out" onClick={() => setZoom(Math.max(0.5, zoom - 0.25))} />
          <div className="w-20 h-1 bg-secondary rounded-full relative">
            <div
              className="absolute top-0 left-0 h-full bg-primary rounded-full"
              style={{ width: `${((zoom - 0.5) / 2) * 100}%` }}
            />
          </div>
          <ToolBtn icon={ZoomIn} tooltip="Zoom In" onClick={() => setZoom(Math.min(2.5, zoom + 0.25))} />
          <span className="text-[10px] text-muted-foreground font-mono w-8">{Math.round(zoom * 100)}%</span>
        </div>
      </div>

      {/* Timeline area */}
      <div className="flex flex-1 min-h-0">
        {/* Track headers */}
        <div className="w-32 shrink-0 border-r border-border">
          {/* Ruler header */}
          <div className="h-6 border-b border-border" />
          {tracks.map((track) => (
            <div
              key={track.id}
              className="h-12 flex items-center gap-1 px-2 border-b border-border"
            >
              <span
                className={`text-[11px] font-mono font-semibold w-6 ${
                  track.type === "video" ? "text-primary" : "text-ready"
                }`}
              >
                {track.label}
              </span>
              <div className="flex gap-0.5 ml-auto">
                <button
                  onClick={() => toggleTrackProp(track.id, "muted")}
                  className={`h-5 w-5 rounded flex items-center justify-center text-[9px] ${
                    track.muted ? "bg-recording/20 text-recording" : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {track.muted ? <VolumeX className="h-3 w-3" /> : "M"}
                </button>
                <button
                  onClick={() => toggleTrackProp(track.id, "solo")}
                  className={`h-5 w-5 rounded flex items-center justify-center text-[9px] ${
                    track.solo ? "bg-warning/20 text-warning" : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  S
                </button>
                <button
                  onClick={() => toggleTrackProp(track.id, "locked")}
                  className={`h-5 w-5 rounded flex items-center justify-center ${
                    track.locked ? "text-recording" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Lock className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Scrollable timeline */}
        <div className="flex-1 overflow-x-auto overflow-y-hidden relative">
          <div style={{ width: totalWidth, minWidth: "100%" }} className="relative">
            {/* Time ruler */}
            <div className="h-6 border-b border-border relative bg-panel">
              {Array.from({ length: Math.ceil(TOTAL_FRAMES / 24) + 1 }).map((_, i) => {
                const frame = i * 24;
                const x = frame * PIXELS_PER_FRAME * zoom;
                return (
                  <div key={i} className="absolute top-0 h-full" style={{ left: x }}>
                    <div className="h-2.5 w-px bg-muted-foreground/30" />
                    <span className="text-[8px] font-mono text-muted-foreground/60 ml-0.5">
                      {framesToTimecode(frame)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Tracks */}
            {tracks.map((track) => (
              <div key={track.id} className="h-12 border-b border-border relative">
                {/* Track background pattern */}
                {track.type === "audio" && (
                  <div className="absolute inset-0 opacity-[0.03]" 
                    style={{ 
                      backgroundImage: "repeating-linear-gradient(90deg, hsl(var(--foreground)) 0px, transparent 1px, transparent 4px)",
                    }} 
                  />
                )}

                {track.clips.map((clip) => {
                  const left = clip.startFrame * PIXELS_PER_FRAME * zoom;
                  const width = (clip.endFrame - clip.startFrame) * PIXELS_PER_FRAME * zoom;
                  const isSelected = selectedClipId === clip.id;

                  return (
                    <div
                      key={clip.id}
                      onClick={() => setSelectedClipId(clip.id)}
                      className={`absolute top-1 bottom-1 rounded cursor-pointer transition-all group ${
                        isSelected ? "ring-2 ring-primary ring-offset-1 ring-offset-background" : ""
                      }`}
                      style={{
                        left,
                        width: Math.max(width, 20),
                        backgroundColor: clip.color,
                      }}
                    >
                      {/* Trim handles */}
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-foreground/0 group-hover:bg-foreground/20 rounded-l cursor-col-resize" />
                      <div className="absolute right-0 top-0 bottom-0 w-1 bg-foreground/0 group-hover:bg-foreground/20 rounded-r cursor-col-resize" />

                      {/* Clip content */}
                      <div className="px-1.5 py-0.5 h-full flex flex-col justify-center overflow-hidden">
                        <span className="text-[9px] font-medium text-foreground/90 truncate leading-tight">
                          {clip.name}
                        </span>
                        {clip.camera && (
                          <span className="text-[7px] text-foreground/50 truncate">
                            {clip.camera} {clip.scene && `• ${clip.scene}`}
                          </span>
                        )}
                      </div>

                      {/* Audio waveform decoration for audio tracks */}
                      {track.type === "audio" && (
                        <div className="absolute inset-x-0 bottom-0 h-3 flex items-end gap-px px-1 opacity-40">
                          {Array.from({ length: Math.floor(width / 3) }).map((_, i) => (
                            <div
                              key={i}
                              className="w-[2px] bg-foreground/60 rounded-t"
                              style={{ height: `${Math.random() * 100}%` }}
                            />
                          ))}
                        </div>
                      )}

                      {/* Transition indicator between clips */}
                      {isSelected && (
                        <div className="absolute -right-1 top-1/2 -translate-y-1/2 h-4 w-2 bg-primary/60 rounded-r flex items-center justify-center">
                          <div className="w-0.5 h-2 bg-primary" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}

            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 z-20 pointer-events-none"
              style={{ left: playheadFrame * PIXELS_PER_FRAME * zoom }}
            >
              {/* Playhead handle */}
              <div className="w-3 h-4 -ml-1.5 bg-recording rounded-b-sm" />
              {/* Playhead line */}
              <div className="w-px h-full bg-recording mx-auto" />
            </div>

            {/* Snap indicator */}
            {snapping && (
              <div
                className="absolute top-0 bottom-0 w-px bg-warning/30 z-10 pointer-events-none"
                style={{ left: 290 * PIXELS_PER_FRAME * zoom }}
              />
            )}
          </div>
        </div>
      </div>

      {/* Transitions drawer */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-t border-border bg-panel">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider mr-2">Transitions</span>
        {["Cut", "Fade", "Dissolve", "Wipe", "Cinematic Blur"].map((t) => (
          <button
            key={t}
            className="text-[10px] px-2.5 py-1 rounded bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors"
            onClick={() => toast(`${t} transition applied`)}
          >
            {t}
          </button>
        ))}
      </div>
    </div>
  );
}

function ToolBtn({
  icon: Icon,
  tooltip,
  active,
  onClick,
}: {
  icon: any;
  tooltip: string;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      title={tooltip}
      className={`h-7 w-7 rounded flex items-center justify-center transition-colors ${
        active
          ? "bg-primary/20 text-primary"
          : "text-muted-foreground hover:text-foreground hover:bg-secondary"
      }`}
    >
      <Icon className="h-3.5 w-3.5" />
    </button>
  );
}
